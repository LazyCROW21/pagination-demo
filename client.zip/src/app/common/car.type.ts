export type Car = {
    id: number;
    maker: string;
    model: string;
    year: number;
};